# Generate your own project boilerplate with NodeJS

## Clone Repo

```
git clone https://github.com/onlinegurucool/generate-project-node.git
```

## Install Dependncies 

```
npm install 
```

## Install this package globally in your system

```
npm link 
```

## Generate or *starproject* new project


> Learn more about how it works [here](https://medium.com/northcoders/creating-a-project-generator-with-node-29e13b3cd309)

